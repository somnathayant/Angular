export class LoginDto{
    name:string;
    password:string;
}