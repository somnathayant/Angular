import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejetComponentComponent } from './rejet-component.component';

describe('RejetComponentComponent', () => {
  let component: RejetComponentComponent;
  let fixture: ComponentFixture<RejetComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RejetComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejetComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
