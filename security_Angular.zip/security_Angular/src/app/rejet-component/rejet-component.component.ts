import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejet-component',
  templateUrl: './rejet-component.component.html',
  styleUrls: ['./rejet-component.component.css']
})
export class RejetComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
