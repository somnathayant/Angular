import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import {Router, NavigationExtras,ActivatedRoute} from "@angular/router";
import { LoginDto } from './login.model';
import { AuthGurdService } from './auth-gurd.service';
import { LoginServiceService } from './login-service.service';
@Component({
  selector: 'app-root',
  /* templateUrl: './app.component.html' */
  templateUrl: './login.component.html'
})
export class HomeComponent {
  title = 'lazyProject1';
  
  empLoginForm: FormGroup;
 
  constructor(private fb: FormBuilder,private loginService:LoginServiceService,private route:Router) {

  }
  ngOnInit() {
    this.empLoginForm = this.fb.group({
      'name': new FormControl(''),
      'password': new FormControl(''),
       
    });
   
  }
  loginEmp(emp:LoginDto) {//same identical property for the formcontrolname
            if(emp.name!="somnath"){
              localStorage.setItem('name','');
            }
    let isLoggedIn=this.loginService.isAuthenticated(emp)

       if(isLoggedIn){
          this.route.navigate(['/welcome'])
       }else{
        this.route.navigate(['/reject']);
       }
  }

}