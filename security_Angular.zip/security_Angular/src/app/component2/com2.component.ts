import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './com2.html'
  
})
export class Com2 {
  title = 'lazyProject1';
}