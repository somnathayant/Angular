import { Injectable } from '@angular/core';
import { LoginDto } from './login.model';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  constructor() { }

  public isAuthenticated(emp:LoginDto):boolean{

        if(emp.name=="somnath"){
          alert(emp.name);
          localStorage.setItem('name',emp.name);
          return true;
        }else{
          alert("no");
          return false;
        }
    

  }
}
