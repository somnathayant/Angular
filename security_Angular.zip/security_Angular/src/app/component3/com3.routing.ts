import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { Com3 } from "./com3.component";
 
const routes: Routes = [
    { path:"", component: Com3 }
];
 
@NgModule({
    exports: [RouterModule],
    imports:[RouterModule.forChild(routes)]
})
export class Com3Routing{
    
} 


