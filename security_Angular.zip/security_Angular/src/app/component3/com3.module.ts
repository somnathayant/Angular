import { NgModule } from "@angular/core";
import { Com3Routing } from "./com3.routing";
import { Com3 } from "./com3.component";
 
@NgModule({
    declarations:[Com3],
    imports:[Com3Routing],
    providers: []
    
})
export class Com3Module{
 
}