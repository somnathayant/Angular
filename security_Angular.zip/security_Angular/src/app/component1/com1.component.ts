import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './com1.html'
  
})
export class Com1 {
  title = 'lazyProject1';
}