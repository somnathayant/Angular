import { NgModule } from "@angular/core";
import { Com1Routing } from "./com1.routing";
import { Com1 } from "./com1.component";
 
@NgModule({
    declarations:[Com1],
    imports:[Com1Routing],
    providers: []
    
})
export class Com1Module{
 
}