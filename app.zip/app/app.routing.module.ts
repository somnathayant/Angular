import { ModuleWithProviders } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import{HomeComponent}from './home.component';

export const router:ModuleWithProviders=RouterModule.forRoot([
                     {path:'',component:LoginComponent},
			         {path:'home',component:HomeComponent},
                    {path:'home/:value',component:HomeComponent},
                      
                  ])
