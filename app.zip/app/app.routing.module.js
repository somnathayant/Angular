"use strict";
var router_1 = require("@angular/router");
var login_component_1 = require("./login.component");
var home_component_1 = require("./home.component");
exports.router = router_1.RouterModule.forRoot([
    { path: '', component: login_component_1.LoginComponent },
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'home/:value', component: home_component_1.HomeComponent },
]);
//# sourceMappingURL=app.routing.module.js.map