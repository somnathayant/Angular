export class EmpMst {
    empName:String;
    empRoll:number;
 }

 
