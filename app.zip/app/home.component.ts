import { Component,OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import {ActivatedRoute,Router} from '@angular/router';
@Component({
  selector: 'child',
  templateUrl: 'app/home.html'
  
})
export class HomeComponent implements OnInit { 

          _valueFromParent:string;
          public firstname: string;
         constructor(private route:ActivatedRoute,private router:Router) {
          
         }

       @Input()
        set valueFromParent(empId : string ){
          alert("we are in child component"+empId);
            this._valueFromParent = empId; 

        }
        get valueFromParent(){
            return this._valueFromParent;
        }
        @Output() toParent :EventEmitter<string> = new EventEmitter<string>();
      
        ngOnInit() {
             /* this.route.queryParams.subscribe(params => {
              this.firstname=params["value"];*/

            this.firstname=this.route.snapshot.params['value'];
            
              alert("==="+this.firstname);
              if(this.firstname!=undefined){
                alert(this.firstname);
              }
              else{
                 alert("No data at navigation");
              }
           // });
            
          
          };
          
          return(){
            // this.router.navigate(['']);
           
            this.toParent.emit("Vinit showing child component");
            
          }
    
}

    

