import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpModule} from '@angular/http';

import { AppComponent } from './app.component';
import{EmpComponent} from './emp.component';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import{router} from './app.routing';
import {EmpService} from './emp.service';

import {ManagerComponent1}from './manager.component';

@NgModule({
  declarations: [
    AppComponent,EmpComponent,ManagerComponent1,
    
  ],
  imports: [
    BrowserModule,FormsModule ,router,BrowserAnimationsModule, ReactiveFormsModule,HttpModule
  ],
  providers: [EmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
