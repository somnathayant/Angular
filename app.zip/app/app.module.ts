import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent }  from './login.component';
import { AppComponent }  from './app.component';
import {HttpModule, Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import {router} from './app.routing.module';
import { RouterModule, Routes } from '@angular/router';
import{HomeComponent}from './home.component';
import {LoginService} from './login.service';
@NgModule({
  imports:      [ BrowserModule, BrowserAnimationsModule, ReactiveFormsModule,
                  FormsModule,HttpModule,router],
  declarations: [ LoginComponent,AppComponent,HomeComponent],
  providers:[LoginService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
