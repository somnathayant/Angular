"use strict";
var LoginMst = (function () {
    function LoginMst() {
    }
    return LoginMst;
}());
exports.LoginMst = LoginMst;
//# sourceMappingURL=login.model.js.map