import { Component,OnInit } from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import{LoginService} from './login.service';
import{LoginMst} from './login.model';
import {Router, NavigationExtras} from "@angular/router";

@Component({
  selector: 'parent',
  templateUrl: 'app/login.html',
  
  
})
export class LoginComponent implements OnInit { 
        
        userform: FormGroup;
        submitted: boolean;
        description: string;
        fromChild:string;
        isShown:boolean;

        constructor(private fb: FormBuilder,private loginService:LoginService,private router: Router) {
    
        }
        ngOnInit() {
            this.isShown=false;
            
            //this.description='';
        
            this.userform = this.fb.group({
                 'userId': new FormControl('',Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(10)])),
                 'password':new FormControl('',Validators.pattern('^[^0-9]+$')),
                

                /* 'userId': new FormControl(''),
                 'password':new FormControl(''),
*/

            });
    }

    checkUser(loginUser:LoginMst){//userform.value
                //alert("======"+loginUser.userId);
              //  this.router.navigate(['/home',loginUser.userId]);
               //this.router.navigate(['/home']);

                this.isShown=false;
               // this.loginService.getUserDetails
               this.loginService.getUserDetails(loginUser).subscribe((data)=>{
                   
        },
        err=>{

        },
        () => { console.log('Method Executed') }
        );
       

  }
  
    home(){//clicking on home anchor in login component it will route to home component
         
           //this.isShown=true;
           this.description="vinit learning Angular";
       
       
    }
   
    fromChildMethod(value:any){
       
        this.fromChild=value;

    }
    

}
