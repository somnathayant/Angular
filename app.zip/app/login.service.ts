import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import { URLSearchParams } from '@angular/http';

import {LoginMst}from './login.model';

import 'rxjs/Rx';

@Injectable()
export class LoginService {

  url:string;
 options: RequestOptionsArgs;
  
  constructor( private nativeHttp: Http) {
       

  }
  getUserDetails(loginMst:LoginMst):Observable<LoginMst> {



    this.url="http://localhost:8080/corsRestForAng4/angLoging";
    return this.nativeHttp.post(this.url,loginMst).map(res => res.json());
      
  }


}
