import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmpMst } from './emp.model';
import { EmpService } from './emp.service';
import {Router, NavigationExtras,ActivatedRoute} from "@angular/router";

@Component({
  selector: 'parent',
  templateUrl: './manager.component.html',
  
})
export class ManagerComponent1 implements OnInit {
  empForm: FormGroup;
  empObj: EmpMst;
  empList:EmpMst[]=[];
  showTable:boolean;
 // students:StudentMst[]=[];
  constructor(private fb: FormBuilder, private empService: EmpService,private router: Router,private route:ActivatedRoute) {

        
  }
  ngOnInit() {
    this.empForm = this.fb.group({
      'empName': new FormControl(''),
      'empRoll': new FormControl('')
    });
    
     let empName=this.route.snapshot.params['empName'];
     
     

    this.showTable=false;
  }

  goNext(){
    this.router.navigate(['/mngComponent']);//with out carry value

  }
  saveEmp(emp: EmpMst) {//same identical property for the formcontrolname
    alert(emp.empName);
    alert(emp.empRoll);

     this.router.navigate(['/mngComponent',emp.empName]);//with carry value


    // this.router.navigate(['/empComponent',emp.empName]);
    //this.students= this.stService.getLocalData(student);//
    //this.router.navigate(['/emp',student.studentName]);//carry value



    this.empService.getServerData(emp).subscribe((data) => {
      this.empList = data;
      this.showTable=true;

    },
      err => {

      },
      () => { console.log('Method Executed') }
    );
  }


}


