export class LoginMst {
    userId:string
    firstname: string;
    lastname:string;
    middleName:string;
    password:string;
    description:string;
    
 }

 