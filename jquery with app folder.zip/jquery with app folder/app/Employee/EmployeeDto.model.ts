export class EmployeeDto{
	 empId:number;
     addressid:number;
	 deptId:number;
	 name:String;
	 dob:Date;
	 salary:number;
	 city:String;
	 state:String;
	 pincode:number;
	 deptName:String;


}