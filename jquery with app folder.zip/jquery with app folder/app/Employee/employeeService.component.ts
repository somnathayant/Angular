import { Injectable, OnInit } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import {  Http,   Headers,   RequestOptions,   RequestOptionsArgs} from '@angular/http';
import 'rxjs/Rx';
import {EmployeeDto} from './EmployeeDto.model';
import {ServerResponse} from '../serverResponse/serverResponse';

@Injectable()
export class EmpService {
  url: string;
  emp:EmployeeDto;
  constructor(private nativeHttp: Http) {

  }
  saveEmp(emp: EmployeeDto): Observable<ServerResponse> {
  
    this.url="http://localhost:8082/corsRestForAng4/saveEmpData";
    
     return this.nativeHttp.post(this.url,emp).map(res => res.json());
  }

  getEmpForUpdate(employeeId:number):Observable<EmployeeDto> {
    this.emp=new EmployeeDto();
   this.emp.empId=employeeId;
   this.url="http://localhost:8082/corsRestForAng4/findEmpById";
     return this.nativeHttp.put(this.url,this.emp).map(res => res.json());
  }
  uploadFile(file: FormData): Observable<ServerResponse> {
    this.url="http://localhost:8082/corsRestForAng4/saveFile";
     return this.nativeHttp.post(this.url,file).map(res => res.json());
  }

  emps():Observable<EmployeeDto[]> {
   this.url="http://localhost:8082/corsRestForAng4/emps";
     return this.nativeHttp.get(this.url).map(res => res.json());
  }
}