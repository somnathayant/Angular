import {EmpService} from '../employeeService.component';
import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmployeeDto } from "../EmployeeDto.model";
import {Router, NavigationExtras,ActivatedRoute} from "@angular/router";
import { DatePipe } from '@angular/common';
import { stringify } from '@angular/core/src/render3/util';
@Component({
  selector: 'parent',
  templateUrl: './updateEmployee.component.html',
})
export class UpdateEmpComponent implements OnInit {
  empForm: FormGroup;
  employeeDto:EmployeeDto;
  empId:number;
  
  constructor(private fb: FormBuilder,private empService:EmpService,private route:ActivatedRoute) {

  }
  ngOnInit() {
    this.empForm = this.fb.group({
      'name': new FormControl(''),
      'salary': new FormControl(''),
       'city': new FormControl(''),
      'pincode': new FormControl(''),
      'deptName': new FormControl(''),
      'state':new FormControl(''),
      'empId':new FormControl(''),
      'addressid':new FormControl(''),
      'deptId':new FormControl(''),
      'dob':new FormControl('')
    });
    this.empId=this.route.snapshot.params['empId'];
   
    this.empService.getEmpForUpdate(this.empId).subscribe((data) => {
      
      if(data.dob!=null){
        
        this.empForm.patchValue({
          'dob':data.dob
          
        });
      }else{
        
        this.empForm.patchValue({
        dob:''
        });
      }
     
      this.empForm.patchValue({
      name:data.name,
      salary: data.salary,
      city: data.city,
      pincode:data.pincode,
      deptName:data.deptName,
      state:data.state,
      empId:data.empId,
      addressid:data.addressid,
      deptId:data.deptId
        });
        

    },
      err => {
       alert("No Such Employee found");
      },
      () => { console.log('Method Executed') }
    );
  
   
   
  }

 
  saveEmp(emp:EmployeeDto) {//same identical property for the formcontrolname
    
    this.empService.saveEmp(emp).subscribe((data) => {
        
        alert("Employee updated !");

    },
      err => {
        alert("Employee not updated !");
      },
      () => { console.log('Method Executed') }
    );
  }


}

