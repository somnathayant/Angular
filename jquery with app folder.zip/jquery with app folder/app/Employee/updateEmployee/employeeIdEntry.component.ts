import {EmpService} from '../employeeService.component';
import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { EmployeeDto } from "../EmployeeDto.model";
import {Router, NavigationExtras,ActivatedRoute} from "@angular/router";

@Component({
  selector: 'parent',
  templateUrl: './employeeIdEntry.html',
})
export class EmployeeIdEntryComponent implements OnInit {
  empForm: FormGroup;
  /* emp:EmployeeDto; */
  constructor(private fb: FormBuilder,private empService:EmpService,private router:Router) {

  }
  ngOnInit() {
    
   this.empForm = this.fb.group({
      'empId': new FormControl(''),
     
    });
   
  }

 
  updateEmp(employee:EmployeeDto) {//same identical property for the formcontrolname
    alert(employee.empId);
    this.router.navigate(['/showUpdateComponent',employee.empId]);
    
  }


}

