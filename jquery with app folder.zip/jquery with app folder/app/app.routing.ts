import {EmployeeIdEntryComponent} from './Employee/updateEmployee/employeeIdEntry.component';
import {UpdateEmpComponent} from './Employee/updateEmployee/updateEmployee.component';
import {SaveEmpComponent} from './Employee/saveEmployee.component';
import { ModuleWithProviders } from '@angular/core';
import { RouterModule } from '@angular/router';
import{ViewEmployeeComponent} from './Employee/viewEmployee.component'
export const router:ModuleWithProviders=RouterModule.forRoot([
                 {path:'',component:SaveEmpComponent},

                  {path:'showUpdateComponent/:empId',component:UpdateEmpComponent},

                  {path:'updateEmployee',component:EmployeeIdEntryComponent},
                  
                  {path:'viewEmployee',component:ViewEmployeeComponent},
                
                      ])