import { ModuleWithProviders } from '@angular/core';
import { RouterModule } from '@angular/router';
import{EmpComponent} from './emp.component';
import{ManagerComponent1}from './manager.component';

export const router:ModuleWithProviders=RouterModule.forRoot([
                 {path:'',component:EmpComponent},

                  {path:'mngComponent/:empName',component:ManagerComponent1},

                  {path:'mngComponent',component:ManagerComponent1},
               
                
                      ])