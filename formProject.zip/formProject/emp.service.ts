import { Injectable, OnInit } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import 'rxjs/Rx';
import {EmpMst} from './emp.model'

@Injectable()
export class EmpService {
  url: string;
  returnedStudents: EmpMst[];
  constructor(private nativeHttp: Http) {

  }

  getLocalData(empMst: EmpMst): EmpMst[] {
    
      alert("In Service");

      
      this.returnedStudents = [
     
      {
        "empName": "Srikant", "empRoll": 44,
      }
        ,
     
     {
        "empName": "Vinit", "empRoll": 44,
      },
     
      {
        "empName": "Mander", "empRoll": 44,
      }
     
      ]
      return this.returnedStudents;

  }

  getServerData(emp: EmpMst): Observable<EmpMst[]> {
    this.url="http://localhost:8081/corsRestForAng4/getEmpData";
    
     return this.nativeHttp.post(this.url,emp).map(res => res.json());
      //return this.nativeHttp.get(this.url,student,).map(res => res.json());
      
  }

}