
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'Product',
  templateUrl: './product.catelog.html',
})
export class ProductComponent implements OnInit {


             ngOnInit() {



             }


}